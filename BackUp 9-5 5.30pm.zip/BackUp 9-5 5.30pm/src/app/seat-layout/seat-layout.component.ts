import { Component, OnInit } from '@angular/core';
import { Alert } from 'selenium-webdriver';
import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-seat-layout',
  templateUrl: './seat-layout.component.html',
  styleUrls: ['./seat-layout.component.css']
})
export class SeatLayoutComponent implements OnInit {
  
constructor() { }

counts=0;
seats:string[]=[];


  public open(X) 
  { 
  
    //current color
    var colr=document.getElementById(X).style.color;
    var c='rgb(46, 204, 113)';//green
    var SeatNo=X;       
 
    if(colr==c) 

      { 
        this.counts-=1;
        const index = this.seats.indexOf(X, 0);
        if (index > -1) {
          this.seats.splice(index, 1);
        }
        document.getElementById("TxtseatNo").innerHTML=this.seats+"";
        document.getElementById(X).style.color='cornflowerblue';
        document.getElementById("seatList").innerHTML=this.seats+"";
       
      }
    else
     {  
       if(this.counts<4)
       {
       this.seats[this.counts]=SeatNo;
       this.counts+=1;
       document.getElementById(X).style.color='rgb(46,204,113)';  
       document.getElementById("TxtseatNo").innerHTML=this.seats+"";
       document.getElementById("seatList").innerHTML=this.seats+"";              
       }
       else{
         alert("Maximun limit reached!");
       }
     }
  }

  public confirm()
  {
    document.getElementById('id01').style.display='block';
    this.seats.forEach(element => {
    document.getElementById(element).style.pointerEvents='none';

    });
                                                                                                        ``
  }
 


  ngOnInit() {
  
  }

}