import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abouts',
  templateUrl: './abouts.component.html',
  styleUrls: ['./abouts.component.css']
})
export class AboutsComponent implements OnInit {

  constructor() { }
  
  MovieName=['BADLA','AVENGERS: END GAME'];
  MovieImage=['../../assets/img/Movie3.jpg','../../assets/img/Movie4.jpg'];
  

  ngOnInit() {
  }

}
