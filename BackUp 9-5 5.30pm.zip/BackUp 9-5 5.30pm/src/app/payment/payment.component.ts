import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor() { }

  public funShow()
  {
document.getElementById('divFirst').innerHTML="dcfgd";

document.getElementById('id01').style.display='block';

  }


  ngOnInit() {
  }

}
