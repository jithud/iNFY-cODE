import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {

  constructor() { }

  onClickSubmit(data) {
    alert("Entered Email id : " + data.TxtMName);
  }

  ngOnInit() {
  }

}
