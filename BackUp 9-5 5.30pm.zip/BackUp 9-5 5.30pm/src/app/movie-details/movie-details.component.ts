import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css'],
  providers: [DatePipe]
})
export class MovieDetailsComponent implements OnInit {

myDate:any = new Date();
myDate1:any = new Date();
constructor(private _Activatedroute:ActivatedRoute,private datePipe: DatePipe){


//this.myDate = this.myDate.getDate() + 1;
//this.myDate1 = this.myDate1.getDate() + 2;

}
  
  MovieName=['AVENGERS: END GAME','KALANK'];
  MovieImage=['../../assets/img/Movie4.jpg','../../assets/img/Movie5.jpg'];
  BannerImage=['../../assets/img/Avengers.jpg','../../assets/img/Kalank.jpg'];
  Screens=[1,2,3,4];
  Time=['10.00 AM','2.00 PM','05.00 PM']
  Language=['English','Hindi'];
  Reldate=['4/26/2019'];
  Category=['Drama','Thriller']
  Duration=['3 hrs 02 mins','3 hrs 02 mins'];
  Description=['The universe is in ruins. With the help of remaining allies, the Avengers must assemble once more in order to undo Thanos actions and restore order to the universe.','Set in 1945, in Pre-Independence India, Kalank is a tale of eternal love.'];

  sub;
  val;

                      //get date of sun&sat

   curr= new Date; // get current date
   first = this.curr.getDate() - this.curr.getDay(); // First day is the day of the month - the day of the week
   saturday = this.first + 6; // last day is the first day + 6
   sunday=this.first + 7;
   
  
public getDivs(a:any,b:any)
{
  document.getElementById(b).style.display='none';
  document.getElementById(a).style.display='block';
}

     ngOnInit() {

      //get values passed over url  
      this.sub=this._Activatedroute.params.subscribe(params => { 
      this.val = params['Id'];        
      });
  }

}
